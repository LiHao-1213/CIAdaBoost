import math
import time
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, matthews_corrcoef, roc_auc_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import RFE
from sklearn.linear_model import Lasso, LogisticRegression
import pandas as pd
from class_CIAdaBoost import CI_adaboost
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB


# 重复实验次数
num_experiments = 1
# 样本数量
n_samples = 1000
n_features = math.ceil(n_samples/10)
n_informative = math.ceil(n_features/10)
n_redundant = math.ceil(n_features/2)
select_n_features = 5
# 不平衡比
imbalance_ratios = [1, 3, 6, 9]



def rfe_selection(X, y, n_features=select_n_features):
    estimator = LogisticRegression()
    selector = RFE(estimator, n_features_to_select=n_features)
    selector.fit(X, y)
    selected_indices = np.where(selector.support_)[0]
    return selected_indices

def lasso_selection(X, y, n_features=select_n_features):
    lasso = Lasso(alpha=0.01)
    lasso.fit(X, y)
    # 获取特征系数的绝对值
    coef_abs = np.abs(lasso.coef_)
    # 获取排名前n_features的特征索引
    selected_indices = np.argsort(coef_abs)[-n_features:][::-1]
    return selected_indices

def CI_adaboost_selection(X, y, n_features=select_n_features):
    clf = CI_adaboost(n_estimator=50, estimator=DecisionTreeClassifier())
    clf.fit(X, y)
    # 获取特征重要性
    feature_importances = clf.calculate_end_feature_weight()
    # 获取排名前n_features的特征索引
    selected_indices = np.argsort(feature_importances)[-n_features:][::-1]
    return selected_indices


for imbalance_ratio in imbalance_ratios:

    # 多数类样本数量
    majority_class_samples = int(n_samples * imbalance_ratio / (imbalance_ratio + 1))
    # 少数类样本数量
    minority_class_samples = n_samples - majority_class_samples

    # RFE 算法评估指标列表
    RFE_evaluate_acc = []
    RFE_evaluate_f1 = []
    RFE_evaluate_mcc = []
    RFE_evaluate_roc_auc = []

    # Lasso 算法评估指标列表
    Lasso_evaluate_acc = []
    Lasso_evaluate_f1 = []
    Lasso_evaluate_mcc = []
    Lasso_evaluate_roc_auc = []

    # CI_adaboost 算法评估指标列表
    ci_evaluate_acc = []
    ci_evaluate_f1 = []
    ci_evaluate_mcc = []
    ci_evaluate_roc_auc = []

    total_start = time.time()

    for experiment in range(num_experiments):
        print(f"Experiment {experiment + 1}/{num_experiments}   ====================================================")

        # 生成模拟数据集，设置类别的权重以实现不平衡
        X, y = make_classification(n_samples=n_samples, n_features=n_features, n_informative=n_informative, n_redundant=n_redundant,
                                   weights=[majority_class_samples / n_samples, minority_class_samples / n_samples],
                                   random_state=experiment)
        y = np.where(y == 0, -1, y)
        # 按照 y 数量配额随机选取 80% 作为训练集，20% 作为测试集
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)


        rfe_indices = rfe_selection(X_train, y_train)
        lasso_indices = lasso_selection(X_train, y_train)
        ci_indices = CI_adaboost_selection(X_train, y_train)

        # 定义基础分类器并评估
        classifiers = {
            'Decision Tree': DecisionTreeClassifier(),
            'KNN': KNeighborsClassifier(),
            'Naive Bayes': GaussianNB(),
            'LogisticRegression': LogisticRegression(),
        }

        feature_selection_methods = {
            'RFE': rfe_indices,
            'Lasso': lasso_indices,
            'ci_adaboost':ci_indices
        }

        for method_name, indices in feature_selection_methods.items():
            print("--------------------------------------------------")
            print(f"Using {method_name} feature selection:")
            X_train_selected = X_train[:, indices]
            X_test_selected = X_val[:, indices]

            current_acc = []  # 用于存储当前特征选择方法下各分类器的准确率
            current_f1 = []
            current_mcc = []
            current_roc_auc = []

            for clf_name, clf in classifiers.items():
                clf.fit(X_train_selected, y_train)
                y_pred = clf.predict(X_test_selected)

                print()

                accuracy = accuracy_score(y_val, y_pred)
                current_acc.append(accuracy)
                print(f"  {clf_name} accuracy: {accuracy:.4f}")

                f1 = f1_score(y_val, y_pred)
                current_f1.append(f1)
                print(f"  {clf_name} f1_score: {f1:.4f}")

                mcc = matthews_corrcoef(y_val, y_pred)
                current_mcc.append(mcc)
                print(f"  {clf_name} mcc: {mcc:.4f}")

                roc_auc = roc_auc_score(y_val, y_pred)
                current_roc_auc.append(roc_auc)
                print(f"  {clf_name} roc_auc: {roc_auc:.4f}")

            # 根据不同的特征选择方法将准确率列表添加到对应的总列表中
            if method_name == 'RFE':
                RFE_evaluate_acc.extend(current_acc)
                RFE_evaluate_f1.extend(current_f1)
                RFE_evaluate_mcc.extend(current_mcc)
                RFE_evaluate_roc_auc.extend(current_roc_auc)
            elif method_name == 'Lasso':
                Lasso_evaluate_acc.extend(current_acc)
                Lasso_evaluate_f1.extend(current_f1)
                Lasso_evaluate_mcc.extend(current_mcc)
                Lasso_evaluate_roc_auc.extend(current_roc_auc)
            elif method_name == 'ci_adaboost':
                ci_evaluate_acc.extend(current_acc)
                ci_evaluate_f1.extend(current_f1)
                ci_evaluate_mcc.extend(current_mcc)
                ci_evaluate_roc_auc.extend(current_roc_auc)
        print()
        print(f"{time.time() - total_start:.4}s")
        print(f"{(time.time() - total_start)/60:.4}min")

    # RFE 算法评估指标平均值计算
    RFE_avg_accuracy = sum(RFE_evaluate_acc) / len(RFE_evaluate_acc)
    RFE_avg_f1 = sum(RFE_evaluate_f1) / len(RFE_evaluate_f1)
    RFE_avg_mcc = sum(RFE_evaluate_mcc) / len(RFE_evaluate_mcc)
    RFE_avg_roc_auc = sum(RFE_evaluate_roc_auc) / len(RFE_evaluate_roc_auc)

    # Lasso 算法评估指标平均值计算
    Lasso_avg_accuracy = sum(Lasso_evaluate_acc) / len(Lasso_evaluate_acc)
    Lasso_avg_f1 = sum(Lasso_evaluate_f1) / len(Lasso_evaluate_f1)
    Lasso_avg_mcc = sum(Lasso_evaluate_mcc) / len(Lasso_evaluate_mcc)
    Lasso_avg_roc_auc = sum(Lasso_evaluate_roc_auc) / len(Lasso_evaluate_roc_auc)

    # CI_adaboost 算法评估指标平均值计算
    ci_avg_accuracy = sum(ci_evaluate_acc) / len(ci_evaluate_acc)
    ci_avg_f1 = sum(ci_evaluate_f1) / len(ci_evaluate_f1)
    ci_avg_mcc = sum(ci_evaluate_mcc) / len(ci_evaluate_mcc)
    ci_avg_roc_auc = sum(ci_evaluate_roc_auc) / len(ci_evaluate_roc_auc)

    print("\nSummary of average evaluation metrics:")
    print("--------------------------------------------------")
    print(f"RFE:")
    print(f"  Average accuracy: {RFE_avg_accuracy:.4f}")
    print(f"  Average F1 score: {RFE_avg_f1:.4f}")
    print(f"  Average MCC: {RFE_avg_mcc:.4f}")
    print(f"  Average ROC-AUC: {RFE_avg_roc_auc:.4f}")
    print("--------------------------------------------------")
    print(f"Lasso:")
    print(f"  Average accuracy: {Lasso_avg_accuracy:.4f}")
    print(f"  Average F1 score: {Lasso_avg_f1:.4f}")
    print(f"  Average MCC: {Lasso_avg_mcc:.4f}")
    print(f"  Average ROC-AUC: {Lasso_avg_roc_auc:.4f}")
    print("--------------------------------------------------")
    print(f"ci_adaboost:")
    print(f"  Average accuracy: {ci_avg_accuracy:.4f}")
    print(f"  Average F1 score: {ci_avg_f1:.4f}")
    print(f"  Average MCC: {ci_avg_mcc:.4f}")
    print(f"  Average ROC-AUC: {ci_avg_roc_auc:.4f}")
    print()

    total_end = time.time()
    toltal_time = total_end - total_start
    print(f"Total time: {toltal_time:.4}s")
    print(f"Total time: {toltal_time/60:.4}min")

    # 将结果保存到 Excel
    results = {
        '模型名称': [
            'RFE',
            'Lasso',
            'ci'
        ],
        '最终平均验证准确率': [
            RFE_avg_accuracy,
            Lasso_avg_accuracy,
            ci_avg_accuracy
        ],
        '最终平均验证 F1 分数': [
            RFE_avg_f1,
            Lasso_avg_f1,
            ci_avg_f1
        ],
        '最终平均验证马修斯相关系数': [
            RFE_avg_mcc,
            Lasso_avg_mcc,
            ci_avg_mcc
        ],
        '最终平均验证 AUC': [
            RFE_avg_roc_auc,
            Lasso_avg_roc_auc,
            ci_avg_roc_auc
        ],
    }

    df = pd.DataFrame(results)
    df.to_excel(f'评估{n_features}特征{n_informative}有用{select_n_features}选入 {imbalance_ratio}不平衡比 {num_experiments}次 {toltal_time/60:.4}min 训练测试划分.xlsx', index=False)

import numpy as np
from sklearn.tree import DecisionTreeClassifier
import os
from sklearn.base import clone
import dcor
print(os.getcwd())
print(os.getcwd())
import math
# 算法模块===============================================================================================================
class CI_adaboost():
    def __init__(self, estimator=DecisionTreeClassifier(), n_estimator=50):
        """
        :param estimator:基础分类器
        :param n_estimator:分类器个数
        """
        self.M = n_estimator
        self.estimator = estimator

    def fit(self, X_train, Y_train):
        """输入数据为numpy数组
        :param X_train: 特征矩阵
        :param Y_train:一维numpy数组;  本程序实现需要满足类别标签为1或者-1
        :return:
        """
        unique_values = np.unique(Y_train)
        if not (-1 in unique_values and 1 in unique_values):
            print("类别标签不满足为1或者-1，退出程序！！")
            exit()
        n_train = len(X_train)
        num_p = np.sum(Y_train == unique_values[0])
        num_n = np.sum(Y_train == unique_values[1])
        imbalance_ratio = max(num_p / num_n, num_n / num_p)

        # 确定多数类和少数类
        if num_p > num_n:
            majority_class = unique_values[0]
            minority_class = unique_values[1]
            majority_num = num_p
            minority_num = num_n
        else:
            majority_class = unique_values[1]
            minority_class = unique_values[0]
            majority_num = num_n
            minority_num = num_p

        self.w = np.ones(n_train) / n_train

        self.classifiers = []
        self.alphas = []
        self.m = 1
        self.feature_weight_all = []

        edge_X = self.edge_feature_mapping(X_train, Y_train)

        while self.m <= self.M:
            clf = clone(self.estimator)
            clf.fit(X_train, Y_train, sample_weight=self.w)
            pred_train_i = clf.predict(X_train)

            ####=================================================================
            feature_weight_t_all = []
            for i in range(math.ceil(imbalance_ratio)):
                # 分别处理多数类和少数类样本的索引
                majority_indices = np.where(Y_train == majority_class)[0]
                minority_indices = np.where(Y_train == minority_class)[0]
                # 对多数类样本按权重 self.w 进行有放回采样
                majority_sampled_indices = np.random.choice(majority_indices, size=minority_num, replace=True,
                                                            p=self.w[majority_indices] / np.sum(
                                                                self.w[majority_indices]))
                # 少数类样本取全部样本
                minority_sampled_indices = minority_indices

                # 合并采样后的索引
                sampled_indices = np.concatenate([majority_sampled_indices, minority_sampled_indices])

                X_train_sampled = X_train[sampled_indices]
                Y_train_sampled = Y_train[sampled_indices]

                #计算特征权重
                feature_weight_ti = self.caculate_feature_weight(X_train_sampled, Y_train_sampled)
                feature_weight_t_all.append(feature_weight_ti)
            #平均特征权重
            feature_weight_t = np.mean(feature_weight_t_all, axis=0)
            self.feature_weight_all.append(feature_weight_t)
            ####=================================================================
            ##空间样本权重指数
            spatial_factor = self.caculate_sample_weight(edge_X, feature_weight_t)
            ####=================================================================
            #空间样本权重因子
            u_t_knn = 1 / (1 + np.exp(-spatial_factor))

            yf_positive_w = (np.multiply((Y_train == pred_train_i), self.w))
            yf_negative_w = (np.multiply((Y_train != pred_train_i), self.w))
            fengzi = np.dot(yf_positive_w, u_t_knn)
            fengmu = np.dot(yf_negative_w, u_t_knn)
            alpha_m = float(0.5 * np.log((fengzi / max(fengmu, 1e-16))))
            www = np.multiply(u_t_knn, np.multiply(self.w, np.exp(-alpha_m * pred_train_i * Y_train)))
            Z_m = np.sum(www)
            self.w = www / Z_m
            self.classifiers.append(clf)
            self.alphas.append(alpha_m)
            self.m += 1
        self.estimators_ = self.classifiers
        self.estimator_weights_ = np.array(self.alphas)

    def caculate_feature_cor(self, X, Y):
        """
        计算特征距离相关系数
        :param X:
        :param Y:
        :return:
        """
        return dcor.distance_correlation(X, Y)

    def caculate_feature_weight(self, X, Y):
        """
        计算特征权重
        :param X:
        :param Y:
        :return:
        """
        X = X.astype(np.float64)
        Y = Y.astype(np.float64)
        num_features = X.shape[1]
        feature_to_feature_correlation = np.zeros((num_features, num_features))
        for i in range(num_features):
            for j in range(i, num_features):
                if i == j:
                    feature_to_feature_correlation[i, j] = 1
                else:
                    dc = self.caculate_feature_cor(X[:, i], X[:, j])
                    feature_to_feature_correlation[i, j] = dc
                    feature_to_feature_correlation[j, i] = dc
        feature_to_Y_correlation = np.zeros(num_features)
        for i in range(num_features):
            dc = self.caculate_feature_cor(X[:, i], Y)
            feature_to_Y_correlation[i] = dc
        avg_correlation_with_others = []
        for i in range(num_features):
            other_features_correlation = np.delete(feature_to_feature_correlation[i], i)
            avg_corr = np.mean(other_features_correlation)
            avg_correlation_with_others.append(avg_corr)
        avg_correlation_with_others = np.where(np.abs(avg_correlation_with_others) < 0.001 , 0.001, avg_correlation_with_others)
        diff_correlation = feature_to_Y_correlation / avg_correlation_with_others
        normalized_diff = diff_correlation / np.sum(diff_correlation)

        return normalized_diff

    def caculate_sample_weight(self, X, feature_weight):
        """
        计算边缘向量空间中, 特征加权的样本权重 ——空间样本权重因子
        :param X:
        :param feature_weight:
        :return:
        """
        num_samples, num_features = X.shape
        sample_weights = np.zeros(num_samples)

        for i in range(num_samples):
            distances = []
            for j in range(num_samples):
                if i != j:
                    # 计算加权的欧氏距离
                    weighted_diff = (X[i] - X[j]) * feature_weight
                    distance = np.sqrt(np.sum(weighted_diff ** 2) + 1e-8)
                    distances.append(distance)
            sample_weights[i] = np.mean(distances)
        sample_weights = sample_weights / np.mean(sample_weights)

        return sample_weights

    def edge_feature_mapping(self, X, Y):
        """
        映射样本到边缘向量特征空间
        :param X:
        :param Y:
        :return:
        """
        unique_classes, class_counts = np.unique(Y, return_counts=True)
        majority_class = unique_classes[np.argmax(class_counts)]
        minority_class = unique_classes[np.argmin(class_counts)]

        majority_indices = np.where(Y == majority_class)[0]
        minority_indices = np.where(Y == minority_class)[0]

        num_samples, num_features = X.shape
        mapped_X = np.zeros((num_samples, num_features))

        for j in range(num_features):
            for i in range(num_samples):
                majority_difference_sum = np.sum(np.abs(X[i, j] - X[majority_indices, j]))  # 计算样本i与多数类样本的该特征j的差值的绝对值之和
                minority_difference_sum = np.sum(np.abs(X[i, j] - X[minority_indices, j]))  # 计算样本i与少数类样本的该特征j的差值的绝对值之和
                mapped_X[i, j] = majority_difference_sum - minority_difference_sum  # 计算映射值
        return mapped_X

    def calculate_end_feature_weight(self):
        """
        :return:    计算最终的特征权重
        """
        feature_weight_all = 0
        for alpha, feature_weight in zip(self.alphas, self.feature_weight_all):
            feature_weight_all += alpha * feature_weight
        normalized_weight = feature_weight_all / np.sum(feature_weight_all)

        return normalized_weight

    def predict(self, X, plan="Voting - Probability"):
        """
        :param X:
        :param plan:      "Voting - Probability":以基分类器的投票预测结果 来计算预测的类概率
                          "Probability - Voting":以基分类器预测的概率 来加权得到分类结果
        :return:
        """
        if plan == "Voting - Probability":
            n_samples = len(X)
            pred = np.zeros(n_samples)
            for alpha, clf in zip(self.alphas, self.classifiers):
                pred += alpha * clf.predict(X)
            result = np.sign(pred)
            result = np.where(result == 0, 1, result)
        elif plan == "Probability - Voting":
            probs = self.predict_proba(X)
            result = (probs[:, 1] >= 0.5).astype(int)
            result = np.where(result == 0, -1, result)

        return result

    def predict_proba(self, X, plan="Voting - Probability"):
        """
        :param X:
        :param plan:      "Voting - Probability":以基分类器的投票预测结果 来计算预测的类概率
                          "Probability - Voting":以基分类器预测的概率 来加权得到分类结果
        :return:
        """
        if plan == "Voting - Probability":
            n_samples = len(X)
            n_classes = 2
            probs = np.zeros((n_samples, n_classes))
            alpha_sum = np.sum(self.alphas)
            all_preds = []
            for clf in self.classifiers:
                preds = clf.predict(X)
                preds = np.where(preds == -1, 0, preds)
                all_preds.append(preds)
            all_preds = np.array(all_preds)
            for c in range(n_classes):
                numerator = np.sum((all_preds == c) * np.array(self.alphas)[:, np.newaxis], axis=0)
                probs[:, c] = numerator / alpha_sum
        elif plan == "Probability - Voting":
            n_samples = len(X)
            probs = np.zeros((n_samples, 2))
            for alpha, clf in zip(self.alphas, self.classifiers):
                class_probs = clf.predict_proba(X)
                probs += alpha * class_probs
            probs /= np.sum(probs, axis=1, keepdims=True)

        return probs




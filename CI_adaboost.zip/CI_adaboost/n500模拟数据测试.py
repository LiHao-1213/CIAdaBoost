import time
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, matthews_corrcoef, roc_auc_score
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
from class_CIAdaBoost import CI_adaboost

# 重复实验次数
num_experiments = 100
# 样本数量
n_samples = 500
n_features = 15
n_informative = 5
n_redundant = 5

# 不平衡比
imbalance_ratios = [1, 3, 6, 9]
for imbalance_ratio in imbalance_ratios:

    clf = DecisionTreeClassifier()

    # 多数类样本数量
    majority_class_samples = int(n_samples * imbalance_ratio / (imbalance_ratio + 1))
    # 少数类样本数量
    minority_class_samples = n_samples - majority_class_samples

    # 存储所有实验的结果
    ci_all_val_accuracies = []
    ci_all_val_f1 = []
    ci_all_val_mcc = []
    ci_all_val_auc = []


    sklearn_all_val_accuracies = []
    sklearn_all_val_f1 = []
    sklearn_all_val_mcc = []
    sklearn_all_val_auc = []


    total_start = time.time()

    for experiment in range(num_experiments):
        print(f"Experiment {experiment + 1}/{num_experiments}")

        # 生成模拟数据集，设置类别的权重以实现不平衡
        X, y = make_classification(n_samples=n_samples, n_features=n_features, n_informative=n_informative, n_redundant=n_redundant,
                                   weights=[majority_class_samples / n_samples, minority_class_samples / n_samples],
                                   random_state=experiment)
        y = np.where(y == 0, -1, y)

        # 按照 y 数量配额随机选取 80% 作为训练集，20% 作为测试集
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

        # 自定义 CI_adaboost 模型
        ci_adaboost = CI_adaboost(n_estimator=50, estimator=clf)
        ci_adaboost.fit(X_train, y_train)

        # 验证集预测
        y_val_pred_ci = ci_adaboost.predict(X_val)
        y_val_proba_ci = ci_adaboost.predict_proba(X_val)[:, 1]

        ci_val_accuracy = accuracy_score(y_val, y_val_pred_ci)
        ci_val_f1_score = f1_score(y_val, y_val_pred_ci)
        ci_val_mcc_score = matthews_corrcoef(y_val, y_val_pred_ci)
        ci_val_auc_score = roc_auc_score(y_val, y_val_proba_ci)


        ci_all_val_accuracies.append(ci_val_accuracy)
        ci_all_val_f1.append(ci_val_f1_score)
        ci_all_val_mcc.append(ci_val_mcc_score)
        ci_all_val_auc.append(ci_val_auc_score)


        # sklearn 的 AdaBoostClassifier 模型
        sklearn_adaboost = AdaBoostClassifier(algorithm="SAMME", n_estimators=50, estimator=clf)
        sklearn_adaboost.fit(X_train, y_train)

        # 验证集预测
        y_val_pred_sklearn = sklearn_adaboost.predict(X_val)
        y_val_proba_sklearn = sklearn_adaboost.predict_proba(X_val)[:, 1]

        sklearn_val_accuracy = accuracy_score(y_val, y_val_pred_sklearn)
        sklearn_val_f1_score = f1_score(y_val, y_val_pred_sklearn)
        sklearn_val_mcc_score = matthews_corrcoef(y_val, y_val_pred_sklearn)
        sklearn_val_auc_score = roc_auc_score(y_val, y_val_proba_sklearn)


        sklearn_all_val_accuracies.append(sklearn_val_accuracy)
        sklearn_all_val_f1.append(sklearn_val_f1_score)
        sklearn_all_val_mcc.append(sklearn_val_mcc_score)
        sklearn_all_val_auc.append(sklearn_val_auc_score)


        print(f"{time.time() - total_start:.4}s")
        print(f"{(time.time() - total_start)/60:.4}min")

    total_end = time.time()
    toltal_time = total_end - total_start
    print(f"Total time: {toltal_time:.4}s")
    print(f"Total time: {toltal_time/60:.4}min")
    print()

    # 计算所有实验的平均验证指标
    ci_final_avg_val_accuracy = np.mean(ci_all_val_accuracies)
    ci_final_avg_val_f1 = np.mean(ci_all_val_f1)
    ci_final_avg_val_mcc = np.mean(ci_all_val_mcc)
    ci_final_avg_val_auc = np.mean(ci_all_val_auc)


    sklearn_final_avg_val_accuracy = np.mean(sklearn_all_val_accuracies)
    sklearn_final_avg_val_f1 = np.mean(sklearn_all_val_f1)
    sklearn_final_avg_val_mcc = np.mean(sklearn_all_val_mcc)
    sklearn_final_avg_val_auc = np.mean(sklearn_all_val_auc)




    # 输出结果
    print("自定义 CI_adaboost 模型：")
    print("最终平均验证准确率: {:.4f}".format(ci_final_avg_val_accuracy))
    print("最终平均验证 F1 分数: {:.4f}".format(ci_final_avg_val_f1))
    print("最终平均验证马修斯相关系数: {:.4f}".format(ci_final_avg_val_mcc))
    print("最终平均验证 AUC: {:.4f}".format(ci_final_avg_val_auc))


    print("\nsklearn 的 AdaBoostClassifier 模型：")
    print("最终平均验证准确率: {:.4f}".format(sklearn_final_avg_val_accuracy))
    print("最终平均验证 F1 分数: {:.4f}".format(sklearn_final_avg_val_f1))
    print("最终平均验证马修斯相关系数: {:.4f}".format(sklearn_final_avg_val_mcc))
    print("最终平均验证 AUC: {:.4f}".format(sklearn_final_avg_val_auc))


    # 将结果保存到 Excel
    results = {
        '模型名称': [
            '自定义 CI_adaboost',
            'sklearn 的 AdaBoostClassifier',
        ],
        '最终平均验证准确率': [
            ci_final_avg_val_accuracy,
            sklearn_final_avg_val_accuracy,
        ],
        '最终平均验证 F1 分数': [
            ci_final_avg_val_f1,
            sklearn_final_avg_val_f1,
        ],
        '最终平均验证马修斯相关系数': [
            ci_final_avg_val_mcc,
            sklearn_final_avg_val_mcc,
        ],
        '最终平均验证 AUC': [
            ci_final_avg_val_auc,
            sklearn_final_avg_val_auc,
        ]
    }

    df = pd.DataFrame(results)
    df.to_excel(f'{n_samples}样本 {imbalance_ratio}不平衡比 {num_experiments}次 {toltal_time/60:.4}min 训练测试划分.xlsx', index=False)

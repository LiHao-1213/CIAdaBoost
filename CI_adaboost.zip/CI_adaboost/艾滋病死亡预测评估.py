import time
import warnings
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, matthews_corrcoef, roc_auc_score, precision_score, recall_score
from sklearn.ensemble import AdaBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
import pandas as pd
from class_CIAdaBoost import CI_adaboost
from ucimlrepo import fetch_ucirepo

# 关闭 ConvergenceWarning
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.linear_model._logistic")
# 关闭 UndefinedMetricWarning
warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.metrics._classification")

aids_clinical_trials_group_study_175 = fetch_ucirepo(id=890)
fileName = "AIDS Clinical Trials Group Study 175"
X = aids_clinical_trials_group_study_175.data.features
y = aids_clinical_trials_group_study_175.data.targets

# 转换为 numpy 数组
X_numpy = X.values
y_numpy = (y.values).ravel()
y_numpy = np.where(y_numpy == 0, -1, y_numpy)
sample_number = len(y_numpy)
recurred_number = np.sum(y_numpy[y_numpy == 1])
print(f"样本数:{sample_number}\t数量(y=1):{recurred_number}\t不平衡比:{(sample_number - recurred_number) / recurred_number:.4}")
print(f"多数类个数:{sample_number - recurred_number}\t少数类个数{recurred_number}")
print(X.shape)

# 重复实验次数
num_experiments = 100

# 分类器
base_clfs = [
    GaussianNB(),
    LogisticRegression(),
    SVC(probability=True),
]

# 所有模型
models = []
model_names = []

# 单独的基础分类器
for clf in base_clfs:
    models.append(clf)
    model_names.append(clf.__class__.__name__)

# AdaBoost 模型
base_clfs_for_adaboost = [DecisionTreeClassifier()]
for clf in base_clfs_for_adaboost:
    adaboost = AdaBoostClassifier(algorithm="SAMME", n_estimators=50, estimator=clf)
    models.append(adaboost)
    model_names.append(f"AdaBoost_{clf.__class__.__name__}")

# CI_adaboost 模型
for clf in base_clfs_for_adaboost:
    ci_adaboost = CI_adaboost(n_estimator=50, estimator=clf)
    models.append(ci_adaboost)
    model_names.append(f"CI_adaboost_{clf.__class__.__name__}")

# 存储所有实验的结果
all_results = {name: {
    'accuracies': [],
    'f1': [],
    'mcc': [],
    'auc': [],
    'precision': [],
    'recall': []
} for name in model_names}

total_start = time.time()

for experiment in range(num_experiments):
    print(f"Experiment {experiment + 1}/{num_experiments}")
    # 将数据划分为训练集和测试集
    X_train, X_val, y_train, y_val = train_test_split(X_numpy, y_numpy, stratify=y_numpy, test_size=0.5,
                                                      random_state=experiment)

    for i, model in enumerate(models):
        model_name = model_names[i]
        print(f"Training {model_name}...")
        model.fit(X_train, y_train)

        # 验证集预测
        y_val_pred = model.predict(X_val)
        if hasattr(model, 'predict_proba'):
            y_val_proba = model.predict_proba(X_val)[:, 1]
        else:
            # 对于 SVC 没有 predict_proba 的情况，可以使用 decision_function
            y_val_proba = model.decision_function(X_val)

        val_accuracy = accuracy_score(y_val, y_val_pred)
        val_f1_score = f1_score(y_val, y_val_pred)
        val_mcc_score = matthews_corrcoef(y_val, y_val_pred)
        val_auc_score = roc_auc_score(y_val, y_val_proba)
        val_precision_score = precision_score(y_val, y_val_pred)
        val_recall_score = recall_score(y_val, y_val_pred)

        all_results[model_name]['accuracies'].append(val_accuracy)
        all_results[model_name]['f1'].append(val_f1_score)
        all_results[model_name]['mcc'].append(val_mcc_score)
        all_results[model_name]['auc'].append(val_auc_score)
        all_results[model_name]['precision'].append(val_precision_score)
        all_results[model_name]['recall'].append(val_recall_score)

    print(f"{time.time() - total_start:.4}s")
    print(f"{(time.time() - total_start) / 60:.4}min")

total_end = time.time()
toltal_time = total_end - total_start
print(f"Total time: {toltal_time:.4}s")
print(f"Total time: {toltal_time / 60:.4}min")
print()

# 计算所有实验的平均验证指标
final_results = {
    '模型名称': [],
    '最终平均验证准确率': [],
    '最终平均验证 F1 分数': [],
    '最终平均验证马修斯相关系数': [],
    '最终平均验证 AUC': [],
    '最终平均验证精确率': [],
    '最终平均验证召回率': []
}

for model_name in model_names:
    final_results['模型名称'].append(model_name)
    final_results['最终平均验证准确率'].append(np.mean(all_results[model_name]['accuracies']))
    final_results['最终平均验证 F1 分数'].append(np.mean(all_results[model_name]['f1']))
    final_results['最终平均验证马修斯相关系数'].append(np.mean(all_results[model_name]['mcc']))
    final_results['最终平均验证 AUC'].append(np.mean(all_results[model_name]['auc']))
    final_results['最终平均验证精确率'].append(np.mean(all_results[model_name]['precision']))
    final_results['最终平均验证召回率'].append(np.mean(all_results[model_name]['recall']))

    print(f"{model_name} 模型：")
    print("最终平均验证准确率: {:.4f}".format(np.mean(all_results[model_name]['accuracies'])))
    print("最终平均验证 F1 分数: {:.4f}".format(np.mean(all_results[model_name]['f1'])))
    print("最终平均验证马修斯相关系数: {:.4f}".format(np.mean(all_results[model_name]['mcc'])))
    print("最终平均验证 AUC: {:.4f}".format(np.mean(all_results[model_name]['auc'])))
    print("最终平均验证精确率: {:.4f}".format(np.mean(all_results[model_name]['precision'])))
    print("最终平均验证召回率: {:.4f}".format(np.mean(all_results[model_name]['recall'])))
    print()

# 将结果保存到 Excel
df = pd.DataFrame(final_results)
df.to_excel(
    f'{fileName} {num_experiments}次 {toltal_time / 60:.4}min 训练测试划分.xlsx',
    index=False)